def testfunction(a):
    return a + 1
